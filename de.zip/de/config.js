import firebase from "firebase";
//require("@firebase/firestore");

const firebaseConfig = {
  apiKey: "AIzaSyACI-5BS3jgO1IngcG2BUndeOHZNTjIpyI",
  authDomain: "e-library-latest-80c69.firebaseapp.com",
  databaseURL: "https://e-library-latest-80c69-default-rtdb.firebaseio.com",
  projectId: "e-library-latest-80c69",
  storageBucket: "e-library-latest-80c69.appspot.com",
  messagingSenderId: "714917724967",
  appId: "1:714917724967:web:516aafa1aca7bc85385f02"
};
if(!firebase.apps.length)
firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
